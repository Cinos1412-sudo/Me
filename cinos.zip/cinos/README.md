# Cinos

Page d'accueil "hero" plein écran pour Cinos — développeur malgache passionné de
tech, jeux vidéo, manga et échecs. Vidéo de fond en boucle, navigation
glassmorphique et typographie cinématique.

## Stack

- React + Vite + TypeScript
- Tailwind CSS
- shadcn/ui (bouton)

## Démarrer

```bash
npm install
npm run dev
```

Puis ouvrir http://localhost:5173

## Build

```bash
npm run build
npm run preview
```
